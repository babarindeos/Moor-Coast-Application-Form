<div class="fixed bottom-0 w-full border-t bg-white">
    <div class="px-20 text-sm py-3 text-center md:text-start">
        &copy;2025. All right reserved.
    </div>
</div>
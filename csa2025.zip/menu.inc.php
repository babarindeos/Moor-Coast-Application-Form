<div class="px-0 py-0 border-b bg-white">
        <div class="flex flex-row justify-between py-4 mx-5 md:mx-20">
                <div><img src="images/logo.jpg"  class="w-40 md:w-64" /></div>
                <div class='flex gap-10 items-center'>
                        <div><a class='underline' href='https://cewsng.funaab.edu.ng/climate-smartconference2025/'>Home</a></div>
                        <div class="hidden md:block">About CSA2025</div>
                        <div class="hidden md:block">Call for Paper</div>
                        <div class="hidden md:block">Registration</div>
                        <div class="hidden md:block">Contact Us</div>
                </div>
        </div>
</div>